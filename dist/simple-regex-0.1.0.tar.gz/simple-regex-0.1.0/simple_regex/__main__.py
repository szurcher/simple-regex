"""simple-regex.__main__: executed when regex directory is called as a script."""

from .regex import main
main()
